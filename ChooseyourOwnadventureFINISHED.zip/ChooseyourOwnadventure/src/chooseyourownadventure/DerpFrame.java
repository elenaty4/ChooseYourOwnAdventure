/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chooseyourownadventure;

import javax.swing.JFrame;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.*;

/**
 *
 * @author elngo
 */
public class DerpFrame extends JFrame{
    private final int FRAME_WIDTH = 1000;
    private final int FRAME_HEIGHT = 700;
    
    //single continue buttons
    private JButton _startNext;
    private JButton _continueToSpace;
    private JButton _THATSANOMOON;
    private JButton _anotherCastle;
    private JButton _blackHole;
    private JButton _oceanContinue;
    private JButton _startOver;
    
    private JLabel _startingPoint; //image
    private JLabel _text; //the image that contains the text
    private JLabel _visual; //the visual for every picture
    
    private JPanel _topVisualPanel;
    private JPanel _centerTextPanel;
    private JPanel _bottomChoicePanel;
    
    private BorderLayout _layout;
    
    private ClickListener _listener;
    
    //CHOICES
    private JButton[] _choiceOptions1;
    private final String[] _CHOICES1 = {"The Circus", "The Ocean", "Outer Space"}; 
    private JButton[] _choiceOptions2;
    private final String[] _CHOICES2 = {"Check the big tent", "Fight the clowns", "You give up"};
    private JButton[] _choiceOptions3;
    private final String[] _CHOICES3 = {"Ask Politely for the door", "Offer to work with the Lion", 
                                        "Transform into a cobra and battle the lion"};
    private JButton[] _choiceOptions4;
    private final String[] _CHOICES4 = {"Towards the moon", "Towards the giant robot fight", 
                                        "A blackhole"};
    private JButton[] _choiceOptions5;
    private final String[] _CHOICES5 = {"Fight Vader Darth", "Join the Dank Side", "KICKFLIP OUTTA HERE"};
    private JButton[] _choiceOptions6;
    private final String[] _CHOICES6 = {"Be sent home", "Become a space gorrilla", "Wander"};
    private JButton[] _choiceOptions7;
    private final String[] _CHOICES7 = {"Side with Hugantor", "Side with Trolvon"};
    private JButton[] _choiceOptions8;
    private final String[] _CHOICES8 = {"Swim to the left", "Swim to the right"};
    private JButton[] _choiceOptions9;
    private final String[] _CHOICES9 = {"Become a crab", "Fight the crabs"};
    private JButton[] _choiceOptions10;
    private final String[] _CHOICES10 = {"Fight the whale", "Coerce the whale"};
    
    public DerpFrame()
    {
        frameComponents();
        setSize(FRAME_WIDTH,FRAME_HEIGHT);
    }
    
    private void frameComponents()
    {
        _listener = new ClickListener();
        _layout = new BorderLayout();
        setLayout(_layout);
        
        //INSTANTIATE CHOICE BUTTONS
        _continueToSpace = new JButton("TO INFINITY AND BEYOND!");
        _continueToSpace.addActionListener(_listener);
        _THATSANOMOON = new JButton("TF TRACTOR BEAM NOOOO!");
        _THATSANOMOON.addActionListener(_listener);
        _anotherCastle = new JButton("Hear Vader's last words");
        _anotherCastle.addActionListener(_listener);
        _blackHole = new JButton("Pass... into the void");
        _blackHole.addActionListener(_listener);
        _oceanContinue = new JButton("Dive in!");
        _oceanContinue.addActionListener(_listener);
        _startOver = new JButton("Quest again");
        _startOver.addActionListener(_listener);
        
        _choiceOptions1 = new JButton[_CHOICES1.length];
        _choiceOptions2 = new JButton[_CHOICES2.length];
        _choiceOptions3 = new JButton[_CHOICES3.length];
        _choiceOptions4 = new JButton[_CHOICES4.length];
        _choiceOptions5 = new JButton[_CHOICES5.length];
        _choiceOptions6 = new JButton[_CHOICES6.length];
        _choiceOptions7 = new JButton[_CHOICES7.length];
        _choiceOptions8 = new JButton[_CHOICES8.length];
        _choiceOptions9 = new JButton[_CHOICES9.length];
        _choiceOptions10 = new JButton[_CHOICES10.length];
        
        _topVisualPanel = new JPanel();
        _bottomChoicePanel = new JPanel();
        _centerTextPanel = new JPanel();
        
        //Adding Visual
        _startingPoint = new JLabel(new ImageIcon("Start.png"));
        _topVisualPanel.add(_startingPoint);
        add(_topVisualPanel, BorderLayout.NORTH);
        
        //Adding Text
        _text = new JLabel(new ImageIcon("Starting text.png"));
        _centerTextPanel.add(_text);
        add(_centerTextPanel, BorderLayout.LINE_START);
       
        //Adding Next Button
        _startNext = new JButton("ONWARDS!");
        _startNext.addActionListener(_listener);
        _bottomChoicePanel.add(_startNext);
        add(_bottomChoicePanel, BorderLayout.CENTER);
    }
    
    
    public class ClickListener implements ActionListener
    {
        
        @Override
        public void actionPerformed(ActionEvent event)
        {
            if(event.getSource() == _startNext)
            {
                //change the top panel
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("Triple road.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                //change the bottom panel
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Triple road text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                //change the choices
                _bottomChoicePanel.removeAll();
                
                for (int i=0; i < _CHOICES1.length; i++)
                {
                    _choiceOptions1[i] = new JButton(_CHOICES1[i]);
                    _bottomChoicePanel.add(_choiceOptions1[i]);
                    _choiceOptions1[i].addActionListener(_listener);
                }
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if (event.getSource() == _choiceOptions1[0]) //THE CIRCUS
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("The big top.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Big top text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                for (int i=0; i < _CHOICES2.length; i++)
                {
                    _choiceOptions2[i] = new JButton(_CHOICES2[i]);
                    _bottomChoicePanel.add(_choiceOptions2[i]);
                    _choiceOptions2[i].addActionListener(_listener);
                }
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
                
            }
            else if (event.getSource() == _choiceOptions1[1]) //THE OCEAN
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("The ocean2.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("At the beach text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_oceanContinue);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if (event.getSource() == _choiceOptions1[2]) //OUTER SPACE
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("the final frontier.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_continueToSpace);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if (event.getSource() == _choiceOptions2[0]) //CHECK THE BIG TENT
            {
                //see the lion
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("The lion.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("The lion text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                for (int i=0; i < _CHOICES3.length; i++)
                {
                    _choiceOptions3[i] = new JButton(_CHOICES3[i]);
                    _bottomChoicePanel.add(_choiceOptions3[i]);
                    _choiceOptions3[i].addActionListener(_listener);
                }
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions2[1]) //FIGHT THE CLOWNS
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("The battle is over.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Fight the clowns test.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();

            }
            else if(event.getSource() == _choiceOptions2[2]) //YOU GIVE UP
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("Surrender to the clown inside.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("You give up text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions3[0]) //Ask politely for the door
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("a gift from the lion.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Ask politely for the door text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions3[1]) //Offer to work for the lion
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("the team up with lion.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Offer to work with the lion text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions3[2]) //Transform into a cobra and battle the lion
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("Cobra battle.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Transform into cobra text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _continueToSpace)
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("the space road.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Space road text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                for (int i=0; i < _CHOICES4.length; i++)
                {
                    _choiceOptions4[i] = new JButton(_CHOICES4[i]);
                    _bottomChoicePanel.add(_choiceOptions4[i]);
                    _choiceOptions4[i].addActionListener(_listener);
                }
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions4[0]) //Towards the moon
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("that'sa no moon.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Towards the moon text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_THATSANOMOON);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions4[1]) //Giant robot fight
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("The battle bots.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Head towards the robot fight text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                for (int i=0; i < _CHOICES7.length; i++)
                {
                    _choiceOptions7[i] = new JButton(_CHOICES7[i]);
                    _bottomChoicePanel.add(_choiceOptions7[i]);
                    _choiceOptions7[i].addActionListener(_listener);
                }
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions4[2]) //A blackhole
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("the black hole.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Enter the black hole text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_blackHole);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _THATSANOMOON)
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("Encounter darth vader.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Inside the death star text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                for (int i=0; i < _CHOICES5.length; i++)
                {
                    _choiceOptions5[i] = new JButton(_CHOICES5[i]);
                    _bottomChoicePanel.add(_choiceOptions5[i]);
                    _choiceOptions5[i].addActionListener(_listener);
                }
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions5[0]) //Fight Vader Darth
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("fight vade.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Battle Vader Darth text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_anotherCastle);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions5[1]) //Join the dank side
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("Join the darkside.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Join the dark side text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions5[2]) //kickflip outta here
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("kickflip outta here.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("kick flip text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _anotherCastle)
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("your door is in another castle.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Battle Vader Darth con text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _blackHole)
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("The great gorrilla spirit.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Inside the black hole text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                for (int i=0; i < _CHOICES6.length; i++)
                {
                    _choiceOptions6[i] = new JButton(_CHOICES6[i]);
                    _bottomChoicePanel.add(_choiceOptions6[i]);
                    _choiceOptions6[i].addActionListener(_listener);
                }
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions6[0]) //Be sent home
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("a new beginning.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Sent home text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            } 
            else if(event.getSource() == _choiceOptions6[1]) //Become a space gorilla
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("transendence.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Become a spirit gorilla text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions6[2]) //Wander
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("those who wander find what they want.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("You wander into nothingness text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions7[0]) //Side with Hugantor
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("gigantor end.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Help Hugantnor text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions7[1]) //Side with Trolvon
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("Voltron end.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Help Trolvon text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if (event.getSource() == _oceanContinue) //dive in
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("The ocean road.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Ocean road text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                for (int i=0; i < _CHOICES8.length; i++)
                {
                    _choiceOptions8[i] = new JButton(_CHOICES8[i]);
                    _bottomChoicePanel.add(_choiceOptions8[i]);
                    _choiceOptions8[i].addActionListener(_listener);
                }
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions8[0]) //Swim left
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("the vrabs.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Crabs text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                for (int i=0; i < _CHOICES9.length; i++)
                {
                    _choiceOptions9[i] = new JButton(_CHOICES9[i]);
                    _bottomChoicePanel.add(_choiceOptions9[i]);
                    _choiceOptions9[i].addActionListener(_listener);
                }
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions8[1]) //Swim right 
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("new the whale.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Whale path text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                for (int i=0; i < _CHOICES10.length; i++)
                {
                    _choiceOptions10[i] = new JButton(_CHOICES10[i]);
                    _bottomChoicePanel.add(_choiceOptions10[i]);
                    _choiceOptions10[i].addActionListener(_listener);
                }
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions9[0]) //Become a crab
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("Become the larger crab.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Become a giant crab.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            } 
            else if(event.getSource() == _choiceOptions9[1]) //Fight the crabs
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("make a door out of the crabs.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Attack the crabs text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions10[0]) //fight the whale
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("become consumed by the whale.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Attack the whale text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if(event.getSource() == _choiceOptions10[1]) //coerce the whale 
            {
                _topVisualPanel.removeAll();
                _visual = new JLabel(new ImageIcon("new whale coerce.png"));
                _topVisualPanel.add(_visual);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Coerce the whale text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _bottomChoicePanel.add(_startOver);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
            else if (event.getSource() == _startOver)
            {
                _topVisualPanel.removeAll();
                _startingPoint = new JLabel(new ImageIcon("Start.png"));
                _topVisualPanel.add(_startingPoint);
                _topVisualPanel.revalidate();
                _topVisualPanel.repaint();
                
                _centerTextPanel.removeAll();
                _text = new JLabel(new ImageIcon("Starting text.png"));
                _centerTextPanel.add(_text);
                _centerTextPanel.revalidate();
                _centerTextPanel.repaint();
                
                _bottomChoicePanel.removeAll();
                _startNext = new JButton("ONWARDS!");
                _startNext.addActionListener(_listener);
                _bottomChoicePanel.add(_startNext);
                _bottomChoicePanel.revalidate();
                _bottomChoicePanel.repaint();
            }
        }
    }
}
