/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chooseyourownadventure;

import javax.swing.JFrame;
/**
 *
 * @author
 */
public class ChooseyourOwnadventure {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame derpFrame = new DerpFrame();
        derpFrame.setTitle("Choose Your Own Adventure!");
        derpFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        derpFrame.setVisible(true); //visibility of the frame. True makes it visible
    }
    
}
